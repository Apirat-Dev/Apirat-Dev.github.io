document.getElementById("generateButton").addEventListener("click", function() {
    // Function to generate random restaurant name
    function getRandomRestaurant(seed, restaurants) {
        // Generate random index
        const randomIndex = Math.floor(Math.random(Math.seedrandom(Date.now())) * restaurants.length);

        // Return random restaurant name
        return restaurants[randomIndex];
    }

    // Load restaurants from JSON file
    fetch('config/restaurants.json')
        .then(response => response.json())
        .then(restaurants => {
            // Get random restaurant name with current timestamp as seed
            const randomRestaurant = getRandomRestaurant(null, restaurants);
            document.getElementById("restaurantName").textContent = "Random restaurant: " + randomRestaurant;
        })
        .catch(error => console.error('Error loading restaurants:', error));
});
