﻿namespace WinFormPrintApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private Label lblHeader;
        private TextBox txtInfo;
        private Button btnPrintPreview;
        private Button btnPrinterSetting;
        private PictureBox picLogo;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblHeader = new Label();
            txtInfo = new TextBox();
            btnPrintPreview = new Button();
            btnPrinterSetting = new Button();
            picLogo = new PictureBox();

            SuspendLayout();

            // picLogo
            picLogo.Dock = DockStyle.Top;
            picLogo.SizeMode = PictureBoxSizeMode.CenterImage;
            picLogo.Height = 80;
            picLogo.Image = Properties.Resources.company_logo; // ใส่โลโก้ของคุณใน Resources

            // lblHeader
            lblHeader.Dock = DockStyle.Top;
            lblHeader.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            lblHeader.TextAlign = ContentAlignment.MiddleCenter;
            lblHeader.Text = "Application Form";
            lblHeader.Height = 50;

            // txtInfo
            txtInfo.Multiline = true;
            txtInfo.ReadOnly = true;
            txtInfo.Dock = DockStyle.Fill;
            txtInfo.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            txtInfo.ScrollBars = ScrollBars.Vertical;

            // btnPrinterSetting
            btnPrinterSetting.Text = "Printer Settings";
            btnPrinterSetting.Dock = DockStyle.Bottom;
            btnPrinterSetting.Height = 40;
            btnPrinterSetting.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnPrinterSetting.Click += btnPrinterSetting_Click;

            // btnPrintPreview
            btnPrintPreview.Text = "Print / PDF Preview";
            btnPrintPreview.Dock = DockStyle.Bottom;
            btnPrintPreview.Height = 45;
            btnPrintPreview.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnPrintPreview.Click += btnPrintPreview_Click;

            // MainForm
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(550, 450);
            Controls.Add(txtInfo);
            Controls.Add(btnPrintPreview);
            Controls.Add(btnPrinterSetting);
            Controls.Add(lblHeader);
            Controls.Add(picLogo);
            Name = "MainForm";
            Text = "Application Form";
            ResumeLayout(false);
            PerformLayout();
        }
        #endregion
    }
}
