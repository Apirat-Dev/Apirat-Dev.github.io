﻿using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;
using WinFormPrintApp.Models;

namespace WinFormPrintApp
{
    public partial class MainForm : Form
    {
        private ApplicationForm applicant;
        private PrintDocument printDoc;
        private PageSettings pageSettings = new PageSettings();

        public MainForm()
        {
            InitializeComponent();
            InitMockData();
            InitPrinter();
            DisplayApplicantInfo();
        }

        private void InitMockData()
        {
            applicant = new ApplicationForm
            {
                FullName = "Apirat Lordkaew",
                Position = "Software Developer",
                Phone = "081-234-5678",
                Email = "apirat@example.com",
                Address = "123/45 Sukhumvit Rd, Bangkok",
                ApplyDate = DateTime.Today
            };
        }

        private void DisplayApplicantInfo()
        {
            txtInfo.Text =
                $"Name: {applicant.FullName}\r\n" +
                $"Position: {applicant.Position}\r\n" +
                $"Phone: {applicant.Phone}\r\n" +
                $"Email: {applicant.Email}\r\n" +
                $"Address: {applicant.Address}\r\n" +
                $"Apply Date: {applicant.ApplyDate:dd/MM/yyyy}";
        }

        private void InitPrinter()
        {
            printDoc = new PrintDocument();
            printDoc.DefaultPageSettings = pageSettings;
            printDoc.PrintPage += PrintDoc_PrintPage;
        }

        // ปุ่ม Printer Setting
        private void btnPrinterSetting_Click(object sender, EventArgs e)
        {
            using var dlg = new PageSetupDialog
            {
                Document = printDoc,
                PageSettings = pageSettings,
                AllowMargins = true,
                AllowOrientation = true,
                AllowPaper = true
            };

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                pageSettings = dlg.PageSettings;
            }
        }

        // ปุ่ม Print Preview / Print to PDF
        private void btnPrintPreview_Click(object sender, EventArgs e)
        {
            using var dlg = new PrintDialog
            {
                Document = printDoc,
                UseEXDialog = true
            };

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                // Preview ก่อนพิมพ์
                using var preview = new PrintPreviewDialog
                {
                    Document = printDoc,
                    Width = 1000,
                    Height = 800
                };
                preview.ShowDialog();

                // ถ้าเลือก printer เป็น "Microsoft Print to PDF" → จะ Save เป็น PDF
                // printDoc.Print();  // uncomment ถ้าต้องการพิมพ์จริง
            }
        }

        private void PrintDoc_PrintPage(object sender, PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            float y = 100;
            int marginLeft = 80;
            int pageWidth = e.PageBounds.Width - 160;

            // ฟอนต์
            var headerFont = new Font("Segoe UI", 18, FontStyle.Bold);
            var labelFont = new Font("Segoe UI", 12, FontStyle.Bold);
            var textFont = new Font("Segoe UI", 12);

            // กรอบรอบหน้า
            var borderRect = new Rectangle(marginLeft - 20, 50, pageWidth + 40, 1000);
            g.DrawRectangle(Pens.Black, borderRect);

            // โลโก้ (ถ้ามี)
            if (picLogo.Image != null)
            {
                g.DrawImage(picLogo.Image, marginLeft + pageWidth - 120, 60, 80, 80);
            }

            // หัวเรื่อง
            g.DrawString("APPLICATION FORM", headerFont, Brushes.Black, marginLeft + 200, y);
            y += 100;

            // เส้นคั่น
            g.DrawLine(Pens.Black, marginLeft, y, marginLeft + pageWidth, y);
            y += 20;

            // เนื้อหา
            DrawField(g, "Full Name:", applicant.FullName, labelFont, textFont, ref y, marginLeft);
            DrawField(g, "Position:", applicant.Position, labelFont, textFont, ref y, marginLeft);
            DrawField(g, "Phone:", applicant.Phone, labelFont, textFont, ref y, marginLeft);
            DrawField(g, "Email:", applicant.Email, labelFont, textFont, ref y, marginLeft);
            DrawField(g, "Address:", applicant.Address, labelFont, textFont, ref y, marginLeft);
            DrawField(g, "Apply Date:", applicant.ApplyDate.ToString("dd/MM/yyyy"), labelFont, textFont, ref y, marginLeft);

            y += 60;
            g.DrawString("Signature: ___________________________", textFont, Brushes.Black, marginLeft, y);
        }

        private void DrawField(Graphics g, string label, string value, Font labelFont, Font textFont, ref float y, int marginLeft)
        {
            g.DrawString(label, labelFont, Brushes.Black, marginLeft, y);
            g.DrawString(value, textFont, Brushes.Black, marginLeft + 150, y);
            y += 30;
        }
    }
}
